"""An implementation of the sqr function in a file to be attached and imported"""
def sqr(n):
    return n * n
