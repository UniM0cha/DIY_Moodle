SIMPLEPIE COMPATIBILITY TEST

1) Upload sp_compatibility_test.php to the web-accessible root of your website.
For example, if your website is www.example.com, upload it so that you can get 
to it at www.example.com/sp_compatibility_test.php

2) Open your web browser and go to the page you just uploaded.