.blocks-gdata .mform {
    width: 100%;
}